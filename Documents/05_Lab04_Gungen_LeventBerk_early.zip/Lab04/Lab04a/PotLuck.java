import javax.swing.JFrame;
/**
 *  Pot Luck Game (Hosting Frame)
 * @author  Levent Berk G�ngen
 * @version 1.0 ( 13 Mar 2016 )
 *  
 */ 
public class PotLuck
{
   public static void main( String[] args)
   {        
      // Variables
      JFrame potLuck;
             
      // Program Code
      potLuck = new JFrame( "Pot Luck" );
      potLuck.setDefaultCloseOperation ( JFrame.EXIT_ON_CLOSE );

      potLuck.getContentPane().add( new PotLuckPanel() );

      potLuck.pack();
      potLuck.setVisible( true );
   }

}