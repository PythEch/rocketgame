import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
/**
 *  Pot Luck Panel
 *  with variable button number
 *  and additional options!
 * @author  Levent Berk G�ngen
 * @version 1.1 ( 13 Mar 2016 )
 *  
 */ 
public class PotLuckPanel extends JPanel
{
   // properties
   
   private final int ROWS  = 5;
   private final int COLS = 5;
   
   private JPanel  barPanel;
   private JPanel  optionsPanel;
   private JPanel  upperPanel;
   private JPanel  buttonPanel;
   private JButton newGame; 
   private JButton exit;
   private JButton[][] buttons;
   private JProgressBar theBar;
   
   private int prizeX; // col number of prize button
   private int prizeY; // row number of prize button
   
   // constructor
   public PotLuckPanel()
   {
      barPanel = new JPanel();
      optionsPanel = new JPanel();
      upperPanel = new JPanel();
      buttonPanel = new JPanel();      
      
      //Initializing the options
      newGame = new JButton("New Game");
      exit = new JButton("Exit");
      
      optionsPanel.add( newGame );
      optionsPanel.add( exit );
      
      //Initializing the progress bar
      theBar = new JProgressBar( 0 , COLS * ROWS );
      theBar.setValue( 0 );
      theBar.setOrientation( SwingConstants.HORIZONTAL );
      theBar.setString( " Which button has the prize? " );
      theBar.setPreferredSize( new Dimension( 400 , 25 ) );
      theBar.setStringPainted(true);     
      barPanel.add( theBar , BorderLayout.CENTER );

      //Initializing buttons
      buttons = new JButton[ROWS][COLS];
      for ( int i = 0; i < ROWS ; i++ )
      {
         for ( int j = 0; j < COLS ; j++ )
         {
            buttons[i][j] = new JButton( "[" + i + "," + j + "]" );
            buttonPanel.add( buttons[i][j] );
         }
      }
      buttonPanel.setLayout( new GridLayout( ROWS , COLS ) );
      
      //Determining prize location
      prizeX = (int) ( Math.random() * COLS );
      prizeY = (int) ( Math.random() * ROWS );
//      System.err.println( "DIAG: " + prizeX + " , " + prizeY );
      
      //Adding listeners
      PotLuckListener listener = new PotLuckListener();
      newGame.addActionListener( listener );
      exit.addActionListener( listener );
      for ( int i = 0; i < ROWS ; i++ )
      {
         for ( int j = 0; j < COLS ; j++ )
         {
            buttons[i][j].addActionListener( listener );
         }
      }
      
      //And finally joining up the panels
      setBackground( Color.cyan );
      setPreferredSize( new Dimension( 200 * COLS, 100 * ROWS ) );
      setLayout( new BorderLayout() );
      
      upperPanel.setLayout( new BorderLayout() );
      upperPanel.add( optionsPanel , BorderLayout.NORTH );
      upperPanel.add( barPanel , BorderLayout.SOUTH );
      add( upperPanel, BorderLayout.NORTH );
      add( buttonPanel, BorderLayout.CENTER );
   }
   
   // methods
   
   protected void reinitialize()
   {
      //Selecting new prize location
      prizeX = (int) ( Math.random() * COLS );
      prizeY = (int) ( Math.random() * ROWS );
      
      //Resetting the bar and panels
      theBar.setValue( 0 );
      theBar.setString( " Which button has the prize? " );
      for ( int k = 0; k < ROWS ; k++ )
      {
         for ( int l = 0; l < COLS ; l++ )
         {
            buttons[k][l].setEnabled( true );
         }
      } 
   }
   
   @Override
   public void paintComponent( Graphics g )
   {
      super.paintComponent( g );
   }
   
   // embedded class
   private class PotLuckListener implements ActionListener
   {
      
      public void actionPerformed( ActionEvent e )
      {
         if ( e.getSource() == newGame )
         {
            PotLuckPanel.this.reinitialize();
         }
         else if ( e.getSource() == exit )
         {
            System.exit( 0 );
         }
         else
         {
            for ( int i = 0; i < ROWS ; i++ )
            {
               for ( int j = 0; j < COLS ; j++ )
               {
                  if ( buttons[i][j] == e.getSource() )
                  {
                     if ( j == prizeX && i == prizeY )
                     {
                        //Won: Display win status on bar and disble all buttons
                        theBar.setValue( theBar.getValue() + 1 );
                        for ( int k = 0; k < ROWS ; k++ )
                        {
                           for ( int l = 0; l < COLS ; l++ )
                           {
                              buttons[k][l].setEnabled( false );
                           }
                        } 
                        if ( theBar.getValue() == ROWS * COLS )
                        {
                           theBar.setString( "You had to try every single one? Tough luck!");
                        }
                        else if ( theBar.getValue() == 1 )
                        {
                           theBar.setString( "What luck! You got it on the first try!");
                        }
                        else
                        {
                           theBar.setString( "Congradulations! You got it in " 
                                               + theBar.getValue() + " attempts!");
                        }
                        theBar.setValue( theBar.getMaximum() );
                     }
                     else
                     {
                        //Didn't win: Disable pressed button and update bar
                        theBar.setValue( theBar.getValue() + 1 );
                        buttons[i][j].setEnabled(false);
                        theBar.setString( "Not that one! You used " + theBar.getValue()
                                            + " of " + theBar.getMaximum() + " guesses!");
                     }
                  }
               }
            }
         }
      }
      
   }

}