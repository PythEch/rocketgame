import java.awt.*;
/**
 *  
 * @author  Levent Berk G�ngen
 * @version 1.0 ( 19 Mar 2016 )
 *  
 */ 
public class Balloon extends Circle implements Drawable
{
   // properties
   private final int POP_RADIUS = 100;
   private final int GROWTH_PER_TICK = 1;
   
   private Color color;
   
   // constructors
   public Balloon( int x , int y )
   {
      super( x , y , 25 ); // Minimum radius must be set from within the super constructor
      color = new Color( ( (int) (180*Math.random()) + 70 ) , 
                     ( (int) (180*Math.random()) + 70 ) , ( (int) (180*Math.random()) + 70 ) );
   }

   // methods
   public void draw( Graphics g )
   {
      g.setColor( color );
      g.drawOval( getX() - getRadius() , getY() - getRadius() , 2 * getRadius() , 2 * getRadius() );
   }
   
   public void grow()
   {
      if ( getRadius() <= POP_RADIUS && getRadius() != 0 )
      {
         setRadius( getRadius() + GROWTH_PER_TICK );
      }
      else
      {
         setRadius( 0 );
         setSelected( true );
      }
   }
}