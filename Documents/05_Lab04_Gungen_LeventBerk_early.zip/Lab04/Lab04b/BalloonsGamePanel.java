import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
/**
 *  Balloons Plus - Game Panel
 * @author  Levent Berk G�ngen
 * @version 1.0 ( 19 Mar 2016 )
 *  //ToDo: Additional features *** eg. high score, hig score table, brief tutorial dialog box ...
 */ 
// Assignment Link http://www.cs.bilkent.edu.tr/~david/cs102/assignments/lab04/
public class BalloonsGamePanel extends JPanel
{
   // Properties
   private final int WINDOW_WIDTH = 600;
   private final int WINDOW_HEIGHT = 600;
   private final int TICK_RATE = 100;      //(in milliseconds, decrease to speed up game)
   private final int GAME_LENGTH = 300;    //(in number of ticks)
// private final int SPAWN_PERIOD = 4;     //(if using Spawn Method A )(1 is shortest, higher numbers decrease the spawn rate)
// private final int SPAWN_SIZE = 3;       //(if using Spawn Method A )(0 to X+1 balloons spawn at a time)
      
   private JLabel scoreLabel;
   private int selectedValue; //for ending dialog
   private ShapeContainer balloons;
   private GameListener listener;
   private PinListener  popper;
   private Timer timer;
   private int tickNumber; //same as 'elapsedTime'
   private int score;
   private int points; //for score updating
   
   // Constructor
   public BalloonsGamePanel()
   {
      //Score Label Set-Up
      scoreLabel = new JLabel( "Score: " + score );
      scoreLabel.setAlignmentX( Component.CENTER_ALIGNMENT );
      scoreLabel.setForeground(Color.white);
      
      //Initializations
      balloons = new ShapeContainer();
      listener = new GameListener();
      timer = new Timer( TICK_RATE , listener );
      tickNumber = 0;
      score = 0;
      popper = new PinListener();
      
      //Panel Set-Up
      setBackground ( Color.black );
      setPreferredSize ( new Dimension( WINDOW_WIDTH , WINDOW_HEIGHT ) );
      setLayout( new BoxLayout( this , BoxLayout.Y_AXIS ) );
      addMouseListener( popper );
      add( scoreLabel );
      add( Box.createVerticalStrut( 200 ) );
      
      timer.start();
      
   }
   
   // Methods
   
   public void newGame()
   {
      balloons = new ShapeContainer();
      tickNumber = 0;
      score = 0;
      scoreLabel.setText( "Score: " + score );
      timer.start();
   }
   
   @Override   
   public void paintComponent( Graphics g ) 
   { 
      super.paintComponent( g );
      Shape current;
      
      balloons.resetIterator();
      for ( int i = 0 ; i < balloons.size() ; i++ )
      {
         current = balloons.iterator().next();
         if ( current instanceof Drawable ) //*** unecessary? Container can but dsnt hold non-balloons
         {
            ( (Drawable) current ).draw( g );
         }
      }
      
   }
   
   // Sub-classes
   private class GameListener implements ActionListener
   {
      public void actionPerformed( ActionEvent e )
      {
         Shape current;  
         tickNumber++;
         
         // Expanding balloons
         balloons.resetIterator();
         for ( int i = 0 ; i < balloons.size() ; i++ )
         {
            current = balloons.iterator().next();
            if ( current instanceof Balloon ) //*** unecessary? Container can but dsnt hold non-balloons
            {
               ( (Balloon) current ).grow();
            }
         }
         
         // Spawning new balloons: Method A (Much more customizable but might be too resource intensive... )
//         if ( tickNumber % SPAWN_PERIOD == 0 ) 
//         {
//            for ( int i = 0 ; i < ( Math.random() * SPAWN_SIZE ) ; i++ ) 
//            {
//               balloons.add( new Balloon( (int) ( WINDOW_WIDTH * Math.random() ) ,
//                                                        (int) ( WINDOW_HEIGHT * Math.random() ) ) );
//            }
//         }
         
         // Spawning new balloons: Method B ( Less customizable, better with resource usage )
         if ( balloons.size() < 15 )
         {
            balloons.add( new Balloon( (int) ( WINDOW_WIDTH * Math.random() ) ,
                                       (int) ( WINDOW_HEIGHT * Math.random() ) )  );
         }
         
         // Removing selected balloons
         balloons.removeAllSelected();
         
         // Ending Game
         if ( tickNumber >= GAME_LENGTH )
         {
            timer.stop();
            selectedValue = JOptionPane.showConfirmDialog( BalloonsGamePanel.this , " Play again? " ,
                                                           "Game Over!" , JOptionPane.YES_NO_OPTION );
                                                
            if ( selectedValue == JOptionPane.NO_OPTION )
            {
               System.exit( 0 );
            }
            else if ( selectedValue == JOptionPane.YES_OPTION )
            {
               BalloonsGamePanel.this.newGame();
            }
         }
         
         repaint();
      }
   }
   
   private class PinListener implements MouseListener
   {
      public void mousePressed( MouseEvent e ) 
      {
         //Selecting applicable balloons and updating score
         points = balloons.selectAllAt( e.getX() , e.getY() );
         if ( points > 1 )
         {
            score += points;
            scoreLabel.setText( "Score: " + score );
         }
//       balloons.add( new Balloon( e.getX() , e.getY() ) );// <- Drawing alignment diagnostic
//       System.err.println(" Press @ t = " + tickNumber ); // <- Press registration diagnostic
      }
      
      public void mouseReleased( MouseEvent e ) 
      {
//       System.err.println(" Release @ t = " + tickNumber ); // <- Release registration diagnostic
      }
      
      public void mouseClicked( MouseEvent e )
      {
//       System.err.println(" Click @ t = " + tickNumber ); // <- Click registration diagnostic
      }
      
      public void mouseExited( MouseEvent e ) 
      {
         timer.stop();
      }
      
      public void mouseEntered( MouseEvent e )
      {
         if ( tickNumber < GAME_LENGTH )
         {
            timer.start();
         }
      }
   
   }
   
}