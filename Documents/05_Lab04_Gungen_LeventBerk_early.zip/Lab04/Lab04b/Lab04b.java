import javax.swing.JFrame;
/**
 *  
 * @author  Levent Berk G�ngen
 * @version 1.0 ( 19 Mar 2016 )
 * 
 */ 
public class Lab04b
{
   public static void main( String[] args)
   {        
      // Variables
      JFrame balloonsGame;
        
      // Program Code
      balloonsGame = new JFrame( "Lab04b - Balloons Plus" );
      balloonsGame.add( new BalloonsGamePanel(/***/) );
      balloonsGame.setDefaultCloseOperation ( JFrame.EXIT_ON_CLOSE );
      balloonsGame.pack();
      balloonsGame.setVisible( true );
   }
}