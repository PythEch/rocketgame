/**
 *  Circle Shape
 * @author  Levent Berk G�ngen
 * @version  1.1 ( 17 Mar 2016 )
 *  Change note: added getRadius() & setRadius( int r )
 */ 
public class Circle extends Shape implements Selectable
{
   // properties
   private int radius;
   private boolean selected;
   
   // constructors
   public Circle( int x , int y , int r )
   {
      super( x , y );
      radius = r;
   }
   
   // methods
   
   public int getRadius()
   {
      return radius;
   }
   
   public void setRadius( int r )
   {
      radius = r;
   }
   
   public boolean getSelected()
   {
      return selected;
   }
   
   public boolean setSelected( boolean state )
   {
      selected = state;
      return selected;
   }
   
   public Circle contains ( int x , int y )
   {
      /*
        Method logic: For the point ( x , y ) to be within the 
        circle, the distance of point from the center point
        of the circle ( this.getX() , this.getY() ) must be less than the 
        radius.
       */
      if (  radius > Math.sqrt( (x - this.getX()) * (x - this.getX()) 
                                   + (y - this.getY()) * (y - this.getY()) )  )
      {
         return this;
      }
      else
      {
         return null;
      }
   }
   
   public double getArea()
   {
      return Math.PI * radius * radius;
   }
   
   @Override
   public String toString()
   {
      String str;
      str = ( "a circle with radius: " + radius );
      if ( this.getSelected() )
      {
         str += " - (SELECTED) ";
      }
      else
      {
         str += " - (NOT selected) ";
      }
      return str;
   }
}