import java.awt.Graphics;
/** Drawable interface
 * @author Levent Berk G�ngen
 * @version 1.0 ( 17 Mar 2016 )
 * 
 * */
public interface Drawable
{
   void draw( Graphics g );
}