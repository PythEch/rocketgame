/**
 *  Locatable Interface
 * @author  Levent Berk G�ngen
 * @version  1.0 ( 29 Feb 2016 )
 *  
 */ 
interface Locatable
{
   int getX();
   int getY();
   boolean setLocation( int x , int y ); 
   /* ^setLocation returns a boolean instead of a void in case
       future additons make location-setting restricted, e.g. shapes
       cannot overlap... */
}