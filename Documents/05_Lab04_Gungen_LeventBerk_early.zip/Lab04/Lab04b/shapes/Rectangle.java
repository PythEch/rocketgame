/**
 *  Rectangle Shape
 * @author  Levent Berk G�ngen
 * @version  1.0 ( 29 Feb 2016 )
 *  
 */ 
public class Rectangle extends Shape implements Selectable
{
   // properties
   private int height;
   private int width;
   private boolean selected;
   
   // constructors
   public Rectangle( int x , int y , int w , int h )
   {
      super( x , y );
      width = w;
      height = h;
   }
   // methods
   public double getArea()
   {
      return ( height * width );
   }
   
   public boolean getSelected()
   {
      return selected;
   }
   
   public boolean setSelected( boolean state )
   {
      selected = state;
      return selected;
   }
   
   public Rectangle contains ( int x , int y )
   {
      /*
        Method logic: For the point ( x , y ) to be within the rectangle, 
        the distance of point from the center point of the rectangle 
        ( this.getX() , this.getY() ) must be less than the distance each side is 
        from the center.       
       */
      if (   ( this.getX() + width / 2.0 >= x ) && ( this.getX() - width / 2.0 <= x ) 
              && ( this.getY() + height / 2.0 >= y ) && ( this.getY() - height / 2.0 <= y )   )
      {
         return this;
      }
      else
      {
         return null;
      }
   }
   
   @Override
   public String toString()
   {
      String str;
      str = ( "a rectangle with width " + width + "  and height: " + height );
      if ( this.getSelected() )
      {
         str += " - (SELECTED) ";
      }
      else
      {
         str += " - (NOT selected) ";
      }
      return str;
   }
}