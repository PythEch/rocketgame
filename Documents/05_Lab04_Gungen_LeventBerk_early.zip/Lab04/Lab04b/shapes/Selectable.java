/**
 *  Selectable Interface
 * @author  Levent Berk G�ngen
 * @version  1.0 ( 29 Feb 2016 )
 *  
 */ 
interface Selectable
{
   boolean getSelected(); 
   boolean setSelected( boolean state );
   Shape contains( int x, int y );
}