/**
 *  Shape Object
 * @author  Levent Berk G�ngen
 * @version  1.0 ( 29 Feb 2016 )
 *  
 */ 
public abstract class Shape implements Locatable
{
   // properties
   private int x; // (location)
   private int y; // (location)
   
   // constructors   
   public Shape( int x , int y )
   {
      this.x = x;
      this.y = y;
   }
   
   // methods
   public abstract double getArea();
   
   public int getX()
   {
      return x;
   }
   
   public int getY()
   {
      return y;
   }
   
   public boolean setLocation( int x , int y )
   {
      this.x = x;
      this.y = y;
      return true;
   }
   
}