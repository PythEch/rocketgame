import java.util.ArrayList;
import java.util.Iterator;
/**
 *  Shape Container ( Revised )
 * @author  Levent Berk G�ngen
 * @version  2.0 ( 17 Mar 2016 )
 *  
 */ 
public class ShapeContainer implements Iterable<Shape>
{
   // properties
   private ArrayList<Shape> container;
   private ShapeIterator iterator;
   
   // constructors
   public ShapeContainer()
   {
      container = new ArrayList<Shape>();
      iterator = new ShapeIterator();
   }
   
   // methods
   public void add( Shape s )
   {
      container.add( s );
   }
   
   public double getArea()
   {
      double totalArea;
      
      totalArea = 0;
      for ( int i = 0 ; i < container.size() ; i++ )
      {
         totalArea += ( container.get( i ) ).getArea();
      }
      return totalArea;
   }
   
   public int size()
   {
      return container.size();
   }
   
   public boolean clickSelect( int x , int y ) // for Lab03 A Part (4)
   {
      Selectable[] group; // This array must be used to access selection features of shapes
      int i;
      
      group = new Selectable[ container.size() ];
      for ( int j = 0 ; j < container.size() ; j++ )
      {
         group[j] = (Selectable) container.get(j); // The index of a shape in group always matches that in container
      }
      
      i = 0;
      while ( i < container.size() )
      {
         if ( group[i].contains( x , y ) != null ) //Find the first shape to contain the point
         {
            group[i].setSelected( true );
            return true;
         }
         else
         {
            i++;
         }
      }
      return false;
   }
   
   public int selectAllAt( int x , int y ) 
   {
      int count;
      count = 0;
      Selectable[] group; // This array must be used to access selection features of shapes
      int i;
      
      group = new Selectable[ container.size() ];
      for ( int j = 0 ; j < container.size() ; j++ )
      {
         group[j] = (Selectable) container.get(j); // The index of a shape in group always matches that in container
      }
      
      i = 0;
      while ( i < container.size() )
      {
         if ( group[i].contains( x , y ) != null ) //Check each shape to see if it contains the point
         {
            group[i].setSelected( true );
            count++;
            i++;
         }
         else
         {
            i++;
         }
      }
      return count;
   }
   
   public void deselectAll()
   {
      Selectable[] group; // The array must be used to access selection features of shapes
      
      group = new Selectable[ container.size() ];
      for ( int j = 0 ; j < container.size() ; j++ )
      {
         group[j] = (Selectable) container.get(j); // The index of a shape in group always matches that in container
      }
      
      for ( int i = 0 ; i < container.size() ; i++ )
      {
         group[i].setSelected( false );
      }

   }
   
   public void removeAll()
   {
      container = new ArrayList<Shape>();
   }
   
   public void removeAllSelected()
   {
      Selectable[] group; // The array must be used to access selection features of shapes
      
      group = new Selectable[ container.size() ];
      for ( int j = 0 ; j < container.size() ; j++ )
      {
         group[j] = (Selectable) container.get(j); // The index of a shape in group always matches that in container
      }
      
      for ( int i = 0 ; i < container.size() ; i++ )
      {
         if ( group[i].getSelected() ) 
         {
            container.remove(i);
         }
      }
   }
   
   @Override 
   public String toString()
   {
      String full;
      
      full = "";
      for ( int i = 0 ; i < container.size() ; i++ )
      {
         full += ( "  * " + container.get( i ) ).toString() + " \n" ;
      }
      return full;
   }
    
   public Iterator<Shape> iterator()
   {
      return iterator;
   }
   
   public void resetIterator()
   {
      iterator = new ShapeIterator();
   }
   
   // subclasses
   
   private class ShapeIterator implements Iterator<Shape>
   {
      //properties
      int index;
      
      //contructor
      public ShapeIterator()
      {
         index = 0;
      }
      
      //methods
      public boolean hasNext()
      {
         return ( index < ShapeContainer.this.size() );
      }
      
      public Shape next()
      {
         if ( this.hasNext() )
         {
            index++;
            return container.get( index - 1 );
         }
         else
         {
            index = 0; //
            return null;
         }
      }

   }
}
   
