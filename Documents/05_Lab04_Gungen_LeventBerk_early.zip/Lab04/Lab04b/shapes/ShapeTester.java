//import java.util.Scanner;
/**
 *  Shape Tester Program for Construction and Selection
 * @author  Levent Berk G�ngen
 * @version 1.0 ( 29 Feb 2016 )
 * 
 */
   /* Lab03 A Part (2) Predictions & Results:
    
    1. P: Commenting out this the Circle class getArea() 
       method will not let the program compile as there 
       is no valid way to get a Circle object's area.
       
       R: This indeed happened, with the error message:
       "Circle is not abstract and does not override abstract method getArea() in Shape"
       
    2. P: Making the circle class abstract will cause a
       compiler error in ShapeTester because it will be
       trying to create non-existing Circle objects.
       
       R: Exactly, with err msg: "Circle is abstract; cannot be instantiated"
       
    3. P: Doing both (1.) and (2.) will cause the CTE at (1.)
       
       R: Nope, the CTE at (2.) occured.
    */ /*
public class ShapeTester
{   
   public static void main( String[] args)
   {
      // Constants   
      
      // Variables
      ShapeContainer box;
      Scanner scan;
      
      int selection;
      int temp;  //needed for constructing shapes
      int temp2; //needed for constructing shapes
      int x;     // (location)
      int y;     // (location)
      
      // Program Code
      
      box = new ShapeContainer();
      scan = new Scanner( System.in );
      System.out.println("   Welcome to Shape Box! " );
                            
      do
      {
         // Menu
         System.out.println();
         System.out.println("   Select an option (enter the number) \n" +
          " 1. Add a shape to the box       \n" +
          " 2. Calculate the total area of all shapes in the box    \n" +
          " 3. List the contents of the box \n" +
          " 4. Enter a point and check if it is contained by a shape in this box \n" +
          " 5. Deselect all selected shapes \n" +
          " 6. Remove all selected shapes \n" +
          " 7. Remove all shapes \n" +
          " 8. Quit" );
                   
         // Actions
         selection = verifiedInput();
         
         if (selection == 1)
         {
            // Menu
            System.out.println();
            System.out.println("   Select a shape to add (enter the number) \n" +
                               " 1. Circle    \n" +
                               " 2. Rectangle \n" +
                               " 3. Square    \n" +
                               " 4. Return to main menu" );
            
            selection = verifiedInput();
            
            if (selection == 1)
            {
               System.out.println("   Enter the shape's center point co-ordinates (x,y): " );
               x = verifiedInput();
               y = verifiedInput();
               System.out.println("   Enter its radius: " );
               temp = verifiedInput();
               box.add( new Circle( x , y, temp ) );
            }
            else if (selection == 2)
            {
               System.out.println("   Enter the shape's center point co-ordinates (x,y): " );
               x = verifiedInput();
               y = verifiedInput();
               System.out.println("   Enter its width and then its height: " );
               temp = verifiedInput();
               temp2 = verifiedInput();
               box.add( new Rectangle( x , y , temp , temp2 ) );
            }
            else if (selection == 3)
            {
               System.out.println("   Enter the shape's center point co-ordinates (x,y): " );
               x = verifiedInput();
               y = verifiedInput();
               System.out.println("   Enter its side length: " );
               temp = verifiedInput();
               box.add( new Square( x , y , temp ) );
            }
            else
            {
               // ( will quit )
               selection = 1;
            }
         }
         else if (selection == 2)
         {
            System.out.println( "   Total area of shapes in box: \n   " + box.getArea() );
         }
         else if (selection == 3)
         {
            System.out.println( "   The box contains: \n" + box.toString() );
         }
         else if (selection == 4)
         {
            System.out.println("   Enter the x co-ordinate and the y co-ordinate of your point,");
            temp = verifiedInput();
            temp2 = verifiedInput();
            if ( box.clickSelect( temp , temp2 ) )
            {
               System.out.println( "   A shape was selected! " );
            }
            else
            {
               System.out.println( "   Nothing was selected... " );
            }
         }
         else if (selection == 5)
         {
            box.deselectAll();
            System.out.println( "   All shapes were deselected." );
         }
         else if (selection == 6)
         {
            box.removeAllSelected();
            System.out.println( "   All selected shapes were removed." );
         }
         else if (selection == 7)
         {
            box.removeAll();
            System.out.println( "   The box is now empty." );
         }
         else if (selection == 8)
         {
            //(program will quit)
         }
         else 
         {
            System.err.println( "   Invalid selection! " );
         }
      } while ( selection != 8 );
      System.out.println( "   Have a nice day! " );
   }
   
   private static int verifiedInput() //used to make verifying inputs easier in main program
   {
      Scanner scan;
      boolean inputGood;
      int verified;
      
      scan = new Scanner( System.in );
      inputGood = false;
      verified = -1;
      do 
      {
         if ( scan.hasNextInt() )
         {
            verified = scan.nextInt();
            inputGood = true;
         }
         else
         {
            System.err.println( "   Input error! " );
            scan.nextLine();
         }
      }while ( inputGood == false );
      return verified;
   }
   
}*/