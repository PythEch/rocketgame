/**
 *  Square Shape
 * @author  Levent Berk G�ngen
 * @version 1.0 ( 29 Feb 2016 )
 *  
 */ 
public class Square extends Rectangle implements Selectable
{
   // properties
   private int side; //width and height could have been inherited, 
                     //but this property is in the instructions so why not use it instead?
 
   // constructors
   public Square( int x , int y , int side )
   {
      super( x , y , side , side );
      this.side = side;
   }
   // methods
   
   @Override
   public String toString()
   {
      String str;
      str = ( "a square with side length: " + side );
      if ( this.getSelected() )
      {
         str += " - (SELECTED) ";
      }
      else
      {
         str += " - (NOT selected) ";
      }
      return str;
   }
}