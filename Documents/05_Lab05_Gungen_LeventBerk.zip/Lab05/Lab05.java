import javax.swing.JFrame;
import cs101.sosgame.SOS;
/**
 *    SOS Game Test Class
 * @author  Levent Berk G�ngen
 * @version 1.1 ( 29 Mar 2016 )
 *  lab link: http://www.cs.bilkent.edu.tr/~david/cs102/assignments/lab05/
 */ 
public class Lab05
{
   public static void main( String[] args)
   {    
      // Variables
      SOS game;
      JFrame frame;
       
      // Program Code
      game = new SOS( 5 );
      frame = new JFrame( "Nearly-Marketable SOS!" );
      frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
      frame.add( new SOSGUIPanel(  game , "Player1" , "Player2"  ) );
      frame.pack();
      frame.setVisible( true );
      
      
   }
}