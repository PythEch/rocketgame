import cs101.sosgame.SOS;
/**
 *    Extended SOS Game Class
 *  Assumes SOS class is public
 * @author  Levent Berk G�ngen
 * @version 1.0 ( 29 Mar 2016 )
 */ 
public class SOS2 extends SOS
{
   //Constructor
   public SOS2 ( int dimension )
   {
      super( dimension );
   }
   
   //Methods
   public void setPlayerScore1( int s )
   {
      //super.playerScore1 = s;
   }
   
   public void setPlayerScore2( int s )
   {
      //super.playerScore2 = s;
   }
   
   public void setTurn( int t )
   {
      //super.turn = t;
   }
}