import java.awt.*;
import javax.swing.*;
import cs101.sosgame.SOS;
/**
 *    SOS Game Canvas
 * @author  Levent Berk G�ngen
 * @version 1.1 ( 29 Mar 2016 )
 * 
 */ 
public class SOSCanvas extends JPanel
{
   //Properties
   private SOS sos;
   private int size;     //grid size multiplier
   private int dimension;
   
   //Constructor
   public SOSCanvas( SOS sos )
   {
      super();
      //Initializations
      size = 70;
      this.sos = sos;
      dimension = sos.getDimension();
      
      setPreferredSize( new Dimension( size * ( dimension + 2 ) , size * ( dimension + 2 ) ) );
   }
   
   //Methods
   public int getSizeMultiplier()
   {
      return size;
   }
   
   @Override
   public void paintComponent( Graphics g )
   {
      size = ( this.getHeight() + this.getWidth() ) / 2 / ( dimension + 2 );
      super.paintComponent( g );
      
      //Grid Drawing
      for ( int i = 0 ; i < dimension + 1 ; i++ ) 
      {
         g.drawLine( size * ( i + 1 ) , size , size * ( i + 1 ) , size * ( dimension + 1 ) );
         g.drawLine( size , size * ( i + 1 ) , size * ( dimension + 1 ) , size * ( i + 1 ) );
      }
      
      //Letter Drawing
      g.setFont(new Font("ComicSans", Font.PLAIN, ( getSizeMultiplier() / 2 ) ));
      for ( int y = 0 ; y < dimension ; y++ )
      {
         for ( int x = 0 ; x < dimension ; x++ )
         {
            g.drawString( ( "" + sos.getCellContents( x , y ) ) , size / 2 - size/10 + size * ( y + 1 ) , 
                                                                  size / 2 + size/10 + size * ( x + 1 ) );
         }
      }
   }
   
}