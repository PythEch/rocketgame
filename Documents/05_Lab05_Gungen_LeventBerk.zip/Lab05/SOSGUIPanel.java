import cs101.sosgame.SOS;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.PrintWriter;
import java.util.Scanner;
import java.io.File;
/**
 *    Enhanced GUI for a Nearly-Marketable SOS Game
 * @author  Levent Berk G�ngen
 * @version 1.1 ( 29 Mar 2016 )
 * 
 *  Extra Features:
 *  - Resizable window
 *  - Customize game options at start
 *    (player names, grid size , remembers last inputs)
 *  - Restart option
 *  - Saving a game to and loading a game from a text file ( see method for details ) by command
 *    (Disabled - see details)
 *  - Saving a game move by move and loading last unfinished game when reopening the program
 *    (Replaced previous save feature)
*/
public class SOSGUIPanel extends JPanel
{
   //Properties
      //Core Properties
   private SOS game;
   private SOSCanvas  canvas;
   private JPanel lowerPanel;
   private JPanel buttonPanel;
   private JLabel player1;
   private JLabel player2;
   private String p1Name;
   private String p2Name;
   private ButtonGroup marker;
   private JRadioButton s;
   private JRadioButton o;
   private SOSListener sosListener;
   
      //Extra Feature Properties
   private JPanel startPanel;
   private JLabel titleLabel;
   private JLabel player1Name;
   private JLabel player2Name;
   private JLabel dimensionI;
   private JTextField p1Init;
   private JTextField p2Init;
   private JTextField dimensionSet;
   private JButton proceed;
   private GameActionListener listener;
   
   private JPanel upperPanel;
   private JButton restart;
   private JButton save;
   private JButton load;
   private PrintWriter moveWriter;
   private boolean loadLast;
   
   //Constructor
   public SOSGUIPanel( SOS game , String p1Name , String p2Name )
   {
      super();      
      //Parameter Passing
      this.game = game;
      this.p1Name = p1Name;
      this.p2Name = p2Name;
      
      //Extra Feature: Load last save
      loadLast = false;
      if ( JOptionPane.YES_OPTION == 
          JOptionPane.showConfirmDialog( this , "Would you like to continue the last closed game?" , 
                                         "Welcome to Nearly-Marketable SOS!" , JOptionPane.YES_NO_OPTION ) )
      {
         loadLast = true;
      }
      
      //Extra Feature: Custom Start Panel that Remembers Last Inputs
      startPanel = new JPanel();
      startPanel.setLayout( new GridLayout( 5 , 2 ) );
      startPanel.setSize( new Dimension( 50 , 125 ) );
      listener = new GameActionListener();
      titleLabel = new JLabel( "Game Set-Up" );
      titleLabel.setFont(new Font("Impact", Font.PLAIN, 25 ));
      player1Name = new JLabel( "Player 1 name: ");
      p1Init = new JTextField( p1Name , 10 );
      p1Init.addActionListener( listener );
      player2Name = new JLabel( "Player 2 name: ");
      p2Init = new JTextField( p2Name , 10 );
      p2Init.addActionListener( listener );
      dimensionI = new JLabel( "Dimension: ");
      dimensionSet = new JTextField( "5" , 2 );
      dimensionSet.addActionListener( listener );
      proceed = new JButton( "Start Game!" );
      proceed.addActionListener( listener );
      startPanel.add( titleLabel );
      startPanel.add( new JPanel() );
      startPanel.add( player1Name );
      startPanel.add( p1Init );
      startPanel.add( player2Name );
      startPanel.add( p2Init );
      startPanel.add( dimensionI );
      startPanel.add( dimensionSet );
      startPanel.add( new JPanel() );
      startPanel.add( proceed );
      if ( !loadLast )
      {
      JOptionPane.showOptionDialog( this , startPanel , "SOS Game Set-Up" , JOptionPane.DEFAULT_OPTION , 
                                     JOptionPane.PLAIN_MESSAGE, null, new Object[]{}, null );
      }
      
      //Labels Set-Up
      player1 = new JLabel( this.p1Name + ": 0" );
      player2 = new JLabel( this.p2Name + ": 0" );
      player1.setFont(new Font("Impact", Font.PLAIN, 30 ));
      player2.setFont(new Font("Impact", Font.PLAIN, 30 ));
      player1.setBackground( Color.green );
      player2.setBackground( Color.green );
      player1.setOpaque( true );
      
      //Radiobutton Panel Set-Up
      buttonPanel = new JPanel();
      marker = new ButtonGroup();
      s = new JRadioButton( "S" );
      o = new JRadioButton( "O" );
      s.setSelected( true );
      marker.add( s );
      marker.add( o );
      buttonPanel.add( s );
      buttonPanel.add( o );
      s.setFont(new Font("ComicSans", Font.PLAIN, 25 ));
      o.setFont(new Font("ComicSans", Font.PLAIN, 25 ));
      
      //Lower Panel Set-Up
      lowerPanel = new JPanel();
      lowerPanel.setLayout( new BorderLayout() );
      lowerPanel.add( player1 , BorderLayout.WEST );
      lowerPanel.add( player2 , BorderLayout.EAST );
      lowerPanel.add( buttonPanel , BorderLayout.CENTER );
      
      //Extra Feature: Upper Panel with Save, Load, Restart Options
      upperPanel = new JPanel();
      save = new JButton( "Save V1" );
      load = new JButton( "Load V1" );
      restart = new JButton( "Restart" );
      save.addActionListener( listener );
      load.addActionListener( listener );
      restart.addActionListener( listener );
      //upperPanel.add( save ); //(Replaced by automatic save/load)
      //upperPanel.add( load ); //(Replaced by automatic save/load)
      upperPanel.add( restart );
      
      //Main Panel Set-Up
      sosListener = new SOSListener();
      setLayout( new BorderLayout() );
      canvas = new SOSCanvas( this.game );
      canvas.addMouseListener( sosListener );
      add( canvas , BorderLayout.CENTER );
      add( lowerPanel , BorderLayout.SOUTH );
      add( upperPanel , BorderLayout.NORTH );
      
      //Extra Feature: Load Last and Start Move Saver
      if ( loadLast )
      {
         moveSaveLoad();
      }
      
      startMoveSaving();     
   }
   
   //Methods
   
   public void restart()
   {
      JOptionPane.showOptionDialog( this , startPanel , "SOS Game Set-Up" , JOptionPane.DEFAULT_OPTION , 
                                     JOptionPane.PLAIN_MESSAGE, null, new Object[]{}, null );
      canvas.removeMouseListener( sosListener );
      this.remove( canvas );
      canvas = new SOSCanvas( this.game );
      canvas.addMouseListener( sosListener );
      add( canvas , BorderLayout.CENTER );
      player1.setText( p1Name + ": 0" );
      player2.setText( p2Name + ": 0" );
      player1.setOpaque( true );
      player2.setOpaque( false );
      this.updateUI();
      repaint();
      startMoveSaving();
   }
   
   public void saveGame() //Manual save method (Replaced)
   {
     PrintWriter writer; 
     try
      {
         writer = new PrintWriter("SOSsavegame.txt", "UTF-8");
//         System.err.println( "Saving game..." );
         writer.println( "DO NOT EDIT THIS FILE!" );
         //Stats
         writer.println( p1Name + " " + p2Name + " " + game.getPlayerScore1() 
                         + " " + game.getPlayerScore2() + " " + game.getTurn() );
         writer.println( game.getDimension() );
         //Board
         for ( int i = 0 ; i < game.getDimension() ; i++ )
         {
            for ( int j = 0 ; j < game.getDimension() ; j++ )
            {
               writer.print( game.getCellContents( i , j ) + " " );
            }
            writer.println( "EOL " );
         }
         writer.close();
      }
      catch ( java.io.FileNotFoundException ex )
      {
         System.err.println( " SAVING ERROR! File not found! " );
      }
      catch ( java.io.UnsupportedEncodingException enex )
      {
         System.err.println( " SAVING ERROR! Encoding failed! " );
      }
   }
   
   public void startMoveSaving() 
   {
      try
      {
         moveWriter = new PrintWriter("SOSMoveSaveGame.txt", "UTF-8");
         moveWriter.println( "DO NOT EDIT THIS FILE!" );
         moveWriter.println( this.p1Name + " " + this.p2Name + " " 
                                  + this.game.getDimension() + " " );
         
         moveWriter.flush();
      }
      catch ( java.io.FileNotFoundException ex )
      {
         System.err.println( " SAVING ERROR! File not found! " );
      }
      catch ( java.io.UnsupportedEncodingException enex )
      {
         System.err.println( " SAVING ERROR! Encoding failed! " );
      }
   }
   
   public void moveSave( char so , int x , int y )
   {
      moveWriter.println( so + " " + x + " " + y + " " );
      moveWriter.flush();
   }
   
   public void loadGame() //Loads manual saves (Replaced)
   {
      /*  NOTE:                                                           *
       *  Player scores and the current turn cannot be loaded accurately  *
       *  unless the saved game is replayed idenically while loading (see *
       *  MoveSave) or the needed methods setPlayerScoreX() and setTurn() *
       *  are provided. These are not provided by the SOS class, but can  *
       *  be added in a small extension of it called SOS2, but SOS turned *
       *  out to be private.  */
      Scanner scan;
      String next;
      File savedGame = new File("SOSsavegame.txt");
      SOS2 loadHere;
      int p1Score;
      int p2Score;
      int turnNo;
      int x;
      int y;
      try
      {
         scan = new Scanner( savedGame );
         scan.nextLine();
         //Stats
         p1Name = scan.next();
         p2Name = scan.next();
         p1Score = Integer.parseInt( scan.next() );
         p2Score = Integer.parseInt( scan.next() );
         turnNo  = Integer.parseInt( scan.next() );
         loadHere = new SOS2( Integer.parseInt( scan.next() ) );
         //Board
         x = 1;
         y = 1;
         while ( scan.hasNext() )
         {
            next = scan.next();
            if ( next.equals( "s" ) )
            {
//               System.out.print( "s " ); //<-these lines were used for debugging
               loadHere.play( 's' , x , y );
               y++;
            }
            else if ( next.equals( "o" ) )
            {
//               System.out.print( "o " );
               loadHere.play( 'o' , x , y );
               y++;
            }
            else if ( next.equals( "." ) )
            {
//               System.out.print( ". " );
               y++;
            }
            else if ( next.equals( "EOL" ) )
            {
//               System.out.println( "EOL " );
               x++;
               y = 1;
            }
            else
            {
//               System.out.print( "?" );
            }
         }
         System.out.println( "DIAG:");
         loadHere.printBoard();             // Correctness check: Saving and loading the same game instance
                                            // should print a text copy of the board that matches the canvas.
         
//         loadHere.setPlayerScore1( p1Score ); // <--assumed/added methods
//         loadHere.setPlayerScore2( p2Score );
//         loadHere.setTurn( turnNo );
         game = (SOS) loadHere;
         
         //GUI Preparation (mostly copied from restartGame())
         canvas.removeMouseListener( sosListener );
         this.remove( canvas );
         canvas = new SOSCanvas( game );
         canvas.addMouseListener( sosListener );
         add( canvas , BorderLayout.CENTER );
         player1.setText( p1Name + ": " + p1Score ); 
         player2.setText( p2Name + ": " + p2Score );
         if ( turnNo == 1 )
         {
            player1.setOpaque( true );         
            player2.setOpaque( false );
         }
         else
         {
            player2.setOpaque( true );         
            player1.setOpaque( false );
         }
         this.updateUI();
         repaint();
      }
      catch ( java.io.FileNotFoundException ex )
      {
         System.err.println( " LOADING ERROR! File not found! " );
      }
   }
   
   public void moveSaveLoad()
   {
      Scanner scan;
      String next;
      File savedGame = new File("SOSMoveSaveGame.txt");
      SOS loadHere;
      int x;
      int y;

      try
      {
         scan = new Scanner( savedGame );
         scan.nextLine();
         p1Name = scan.next();
         p2Name = scan.next();
         loadHere = new SOS( Integer.parseInt( scan.next() ) );
         game = loadHere;
         
         while ( scan.hasNext() )
         {
            next = scan.next();
            if ( next.equals( "s" ) )
            {
//               System.out.print( "s " ); //<-these lines were used for debugging
              x = Integer.parseInt( scan.next() );
              y = Integer.parseInt( scan.next() );
               game.play( 's' , x , y );
            }
            else if ( next.equals( "o" ) )
            {
//               System.out.print( "o " );
              x = Integer.parseInt( scan.next() );
              y = Integer.parseInt( scan.next() );
               game.play( 'o' , x , y );
            }
            else
            {
               System.err.println( "LOADING ERROR! File reading problem!" );
            }
         }
//         System.out.println( "DIAG:");
//         game.printBoard();            // Correctness check: Saving and loading the same game instance
                                       // should print a text copy of the board that matches the canvas.
         
         //GUI Preparation (mostly copied from restartGame())
         canvas.removeMouseListener( sosListener );
         this.remove( canvas );
         canvas = new SOSCanvas( game );
         canvas.addMouseListener( sosListener );
         add( canvas , BorderLayout.CENTER );
         player1.setText( p1Name + ": " + game.getPlayerScore1() ); 
         player2.setText( p2Name + ": " + game.getPlayerScore2() );
         if ( game.getTurn() == 1 )
         {
            player1.setOpaque( true );         
            player2.setOpaque( false );
         }
         else
         {
            player2.setOpaque( true );         
            player1.setOpaque( false );
         }
         this.updateUI();
         repaint();
      }
      catch ( java.io.FileNotFoundException ex )
      {
         System.err.println( " LOADING ERROR! File not found! " );
      }
   }
   
   //Embedded Classes
   private class SOSListener extends MouseAdapter // For core features
   {
      @Override
      public void mousePressed( MouseEvent e )
      {
         //Processing Click (Press)
         int x,y;
         y = e.getX() / canvas.getSizeMultiplier();
         x = e.getY() / canvas.getSizeMultiplier();
//         System.err.println( x + " " + y );
         if ( s.isSelected() )
         {
            game.play( 's' , x , y );
//            game.printBoard();
            moveSave( 's' , x , y ); //For extra move save feature
         }
         else
         {
            game.play( 'o' , x , y );
//            game.printBoard();
            moveSave( 'o' , x , y ); //For extra move save feature
         }
         
         //Updating Player Info
         player1.setText( p1Name + ": " + game.getPlayerScore1() );
         player2.setText( p2Name + ": " + game.getPlayerScore2() );
         
         if ( game.getTurn() == 1 )
         {
            player1.setOpaque( true );
            player2.setOpaque( false );
         }
         else
         {
            player1.setOpaque( false );
            player2.setOpaque( true );
         }
         repaint();
         
         //Ending the Game
         if ( game.isGameOver() )
         {
            if ( game.getPlayerScore1() > game.getPlayerScore2() )
            {
               JOptionPane.showMessageDialog( SOSGUIPanel.this , ( p1Name + " wins!" ) ,
                                              " Game Over! " , JOptionPane.INFORMATION_MESSAGE );
            }
            else if ( game.getPlayerScore1() < game.getPlayerScore2() )
            {
               JOptionPane.showMessageDialog( SOSGUIPanel.this , ( p2Name + " wins!" ) ,
                                              " Game Over! " , JOptionPane.INFORMATION_MESSAGE );
            }
            else
            {
               JOptionPane.showMessageDialog( SOSGUIPanel.this , ( "It's a draw!" ) ,
                                              " Game Over! " , JOptionPane.INFORMATION_MESSAGE );
            }
         }
         
      }
   }
   
   private class GameActionListener implements ActionListener // For the extra features
   {
      public void actionPerformed( ActionEvent e )
      {
         String test;
         boolean isOK;
         isOK = true;
         
         if ( e.getSource() == restart )
         {
            SOSGUIPanel.this.restart();
         }
         else if ( e.getSource() == save )
         {
            SOSGUIPanel.this.saveGame();
         }
         else if ( e.getSource() == load )
         {
            SOSGUIPanel.this.loadGame();
         }
         else if ( e.getSource() == p1Init )
         {
            p1Name = p1Init.getText();
         }
         else if ( e.getSource() == p2Init )
         {
            p2Name = p2Init.getText();
         }
         else if ( e.getSource() == dimensionSet )
         {
            test = dimensionSet.getText();
            for ( int i = 0 ; i < test.length() ; i++ ) //int input test
            {
               if ( !Character.isDigit( test.charAt(i) ) )
               {
                  isOK = false;
                  proceed.setEnabled( false );
               }
            }
            if ( isOK )
            {
               game = new SOS( Integer.parseInt( test ) );
               proceed.setEnabled( true );
            }
         }
         else if ( e.getSource() == proceed )
         {
            p1Init.postActionEvent();
            p2Init.postActionEvent();
            dimensionSet.postActionEvent();
            SwingUtilities.getWindowAncestor( proceed ).setVisible( false );
         }
      }
   }
}

